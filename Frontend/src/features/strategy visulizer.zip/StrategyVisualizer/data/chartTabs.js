export const STRATEGY_CHART_TABS = [
  { id: 'payoffgraph', label: 'Payoff Graph' },
  { id: 'pnl_table', label: 'P&L Table (Projected)' },
  { id: 'greeks_table', label: 'Greeks Table (Projected)' },
];